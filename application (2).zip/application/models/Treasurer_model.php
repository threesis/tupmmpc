<?php
	class Treasurer_model extends CI_Model {
		
	}