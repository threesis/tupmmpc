<?php
	class Administrators extends CI_Controller {
		public function admin() {
			// Check login session
			if(!$this->session->userdata('signed_in')) {
				// Set message
				$this->session->set_flashdata('not_signedin', 'You must sign in to continue!');
				// Redirect to sign in page
				redirect('signin');
			} elseif($this->session->userdata('signed_in')) {
				$this->load->view('pages/admin');
			} else {
				show_404();
			}
		}


		// Retrieve loan function
		public function get_loans() {
			// Get all loans from database -> model
			$result = $this->administrator_model->get_all_loan_types();
			echo json_encode($result);
		}

		// Add loan function
		public function add_loan() {
			// Add loan -> modal
			$result = $this->administrator_model->register_loan();
			$msg['success'] = false;
			$msg['type'] = 'add';
			if($result) {
				// If there are data returned from the model.. 
				$msg['success'] = true;
			}
			// Convert $msg to json type to become readable thru ajax request
			echo json_encode($msg);
		}

		// Edit loan function
		public function edit_loan() {
			$result = $this->administrator_model->edit_loan();
			echo json_encode($result);
		}

		// Update loan function
		public function update_loan() {
			$result = $this->administrator_model->update_loan();
			$msg['success'] = false;
			if($result) {
				$msg['success'] = true;
				$msg['type'] = 'update';
			}
			echo json_encode($msg);
		}

		// Delete loan function
		public function delete_loan() {
			$result = $this->administrator_model->delete_loan();
			$msg['success'] = false;
			if($result) {
				$msg['success'] = true;
			}
			echo json_encode($msg);
		}

		// Delete user function
		public function delete_user() {
			$result = $this->administrator_model->delete_user();
			$msg['success'] = false;
			if($result) {
				$msg['success'] = true;
			}
			echo json_encode($msg);
		}

		// Sort member by date
		public function sort_member_date() {
			$result = $this->administrator_model->sort_member_date();
			echo json_encode($result);
		}

		// Sort member by position
		public function sort_member_position() {
			$result = $this->administrator_model->sort_member_position();
			echo json_encode($result);
		}

		// Sort member by date
		public function sort_member_college() {
			$result = $this->administrator_model->sort_member_college();
			echo json_encode($result);
		}

		// Search member function 
		public function search_user() {
			$result = $this->administrator_model->search_user();
			echo json_encode($result);
		}
		
		// Register member function
		public function add_member() {
			$result = $this->administrator_model->add_member();
			$msg['success'] = false;
			if($result) {
				$msg['success'] = true;
			}
			echo json_encode($msg);
		}

		// Retrieve latest member registration date -> model
		public function get_latest_date() {
			$result = $this->administrator_model->get_latest_date();
			echo json_encode($result);
		}

		public function getMember_latest_date() {
			$result = $this->administrator_model->getMember_latest_date();
			echo json_encode($result);
		}

		public function testing() {
			$result = $this->administrator_model->testing();
			echo json_encode($result);
		}

		public function testing1() {
			$result = $this->administrator_model->testing1();
			echo json_encode($result);
		}

		public function getRoles() {
			$result = $this->administrator_model->getRoles();
			echo json_encode($result);
		}

		public function retrieveParentOptions() {
			$result = $this->administrator_model->retrieveParentOptions();
			echo json_encode($result);
		}

		public function retrieveChildOptions() {
			$result = $this->administrator_model->retrieveChildOptions();
			echo json_encode($result);
		}

		public function retrieveRolePermissions() {
			$result = $this->administrator_model->retrieveRolePermissions();
			echo json_encode($result);
		}

		public function setPermissions() {
			$result = $this->administrator_model->setPermissions();
			echo json_encode($result);
		}

		public function setPermissions2() {
			$result = $this->administrator_model->setPermissions2();
			echo json_encode($result);
		}

		public function verifyAccountPassword() {
			$result = $this->administrator_model->verifyAccountPassword();
			echo json_encode($result);
		}

		public function retrieveUserInfo() {
			$result = $this->administrator_model->retrieveUserInfo();
			echo json_encode($result);
		}

		public function updateUserInfo() {
			$result = $this->administrator_model->updateUserInfo();
			echo json_encode($result);
		}
		
		public function encryptCurrentPass() {
			$result = array(
				'currentPass' => md5($this->input->get('currentPass')),
				'desiredNewPass' => md5($this->input->get('desiredNewPass'))
			);
			echo json_encode($result);
		}
		
	}